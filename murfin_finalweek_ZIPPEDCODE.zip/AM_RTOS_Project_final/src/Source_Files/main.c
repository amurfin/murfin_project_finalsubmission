/***************************************************************************//**
 * @file
 * main.c
 *
 * @brief
 * Andrew Murfin's ECEN3753 SP21 Project Rev 0
 *
 ******************************************************************************/

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "em_device.h"
#include "em_chip.h"
#include "em_emu.h"
#include "bsp.h"
#include "main.h"
#include "app.h"
#include "gpio.h"
#include "capsense.h"
#include "display.h"
#include "dmd.h"
#include "glib.h"
#include "bspconfig.h"
#include "textdisplay.h"
#include "retargettextdisplay.h"

// Micrium OS Includes
#include  <bsp_os.h>
#include  "bsp.h"
#include  <cpu/include/cpu.h>
#include  <common/include/common.h>
#include  <kernel/include/os.h>
#include  <kernel/include/os_trace.h>
#include  <common/include/lib_def.h>
#include  <common/include/rtos_utils.h>
#include  <common/include/toolchains.h>

volatile uint32_t msTicks; /* counts 1ms timeTicks */

/* LOCAL TASK STATIC PROTOTYPES */
static  void  MainStartTask (void  *p_arg);
static  void  IdleTask (void  *p_arg);
static  void  SvcPhysicsTask (void  *p_arg);
static  void  LCDGraphicsTask (void  *p_arg);
static  void  MeasureCapsenseTask (void  *p_arg);
static  void  ButtonInLED0OutTask (void  *p_arg);
static  void  LED1OutTask (void  *p_arg);

static	void  SvcPhysicsTimerCallback (OS_TMR p_tmr, void * p_arg);
static	void  MeasureCapsenseTimerCallback (OS_TMR p_tmr, void * p_arg);

// Micrium OS Task Objects
/* Start Task Stack.                                    */
static  CPU_STK  	MainStartTaskStk[MAIN_START_TASK_STK_SIZE];
/* Start Task TCB.                                      */
static  OS_TCB   	MainStartTaskTCB;
/* Idle Task Stack.                                    */
static  CPU_STK  	IdleTaskStk[IDLE_TASK_STK_SIZE];
/* Idle Task TCB.                                      */
static  OS_TCB   	IdleTaskTCB;
/* Service Physics Task Stack.                                    */
static  CPU_STK  	SvcPhysicsTaskStk[SVC_PHYSICS_TASK_STK_SIZE];
/* Service Physics Task TCB.                                      */
static  OS_TCB   	SvcPhysicsTaskTCB;
/* LCD Graphics Task Stack.                                    */
static  CPU_STK  	LCDGraphicsTaskStk[LCD_GRAPHICS_TASK_STK_SIZE];
/* LCD Graphics Task TCB.                                      */
static  OS_TCB   	LCDGraphicsTaskTCB;
/* Measure Capsense Task Stack.                                    */
static  CPU_STK  	MeasureCapsenseTaskStk[MEASURE_CAPSENSE_TASK_STK_SIZE];
/* Measure Capsense Task TCB.                                      */
static  OS_TCB   	MeasureCapsenseTaskTCB;
/* Button In, LED0 Output Task Stack.                                    */
static  CPU_STK  	ButtonInLED0OutTaskStk[BTN_IN_LED0_OUT_TASK_STK_SIZE];
/* Button In, LED0 Output Task TCB.                                      */
static  OS_TCB   	ButtonInLED0OutTaskTCB;
/* LED 1 Output Task Stack.                                    */
static  CPU_STK  	LED1OutTaskStk[LED1_OUT_TASK_STK_SIZE];
/* LED 1 Output Task TCB.                                      */
static  OS_TCB   	LED1OutTaskTCB;

// Other Micrium OS Objects
// OS Timers
static	OS_TMR			SvcPhysicsTimer;
static	OS_TMR			MeasureCapsenseTimer;
static	OS_TMR			LED1BlinkTimer;
// Semaphores
static	OS_SEM			SvcPhysicsTimerSem;
static	OS_SEM			LCDGraphicsSem;
static	OS_SEM			MeasureCapsenseTimerSem;
static	OS_SEM			LED1BlinkTimerSem;
// Flags
static	OS_FLAG_GRP		LED1OutFlags;	// b0 = "FLAG_XMAX_VIOLATION, b1 = "FLAG_PENDLM_FELL_VIOLATION"
// Locks
static 	OS_MUTEX		PendulumParamsLock;
// MsgQ
static	OS_Q			ButtonInLED0OutMsgQ;

// Instantiation of shared data structs
static	PendulumParams	rodParams;

// GLIB Context
static GLIB_Context_t glibContext;

//////////// NON OS FUNCTIONS ////////////

/**
 * @brief
 * OS Helper Function - posts to ButtonInLED0OutMsgQ with the button pushed.
 *
 * @param[in] btn
 * The button pushed
 *
 * @notes
 * Called by GPIO ISR
 *
 */
void postBtnMsgQ(pressedButton btn)
{
	RTOS_ERR err;
	static ButtonMessage msg;
	// post to msgQ
	msg.button = btn;
	OSQPost(&ButtonInLED0OutMsgQ,
			(void *)&msg,
			(OS_MSG_SIZE)sizeof(void *),
			(OS_OPT_POST_ALL + OS_OPT_POST_FIFO),
			&err);
	// check error code
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

/**
 * @brief
 * Initialize values in rodParams to default states
 *
 */
void initRodParams(void)
{
	rodParams.pendulumVersion = PROJECT_VER_4;
	rodParams.pendulumGravityAccel = ACCEL_GRAVITY;
	rodParams.pendulumMass = MASS_BALL;
	rodParams.pendulumLength = LENGTH_POST;
	rodParams.pendulumXMax = VIOLATION_XMAX;
	rodParams.pendulumXMin = VIOLATION_XMIN;
	rodParams.pendulumVariant = PROJECT_VAR_1;
	rodParams.pendulumMaxForce = FORCE_HIGH;
	rodParams.pendulumBallVelocX = 0;
	rodParams.pendulumBallVelocY = 0;
	rodParams.pendulumBallX = BALL_X_DEFAULT;
	rodParams.pendulumBallY = BALL_Y_DEFAULT;
	rodParams.pendulumBaseX = BASE_X_DEFAULT;
	rodParams.pendulumTheta = THETA_DEFAULT;
	rodParams.pendulumForceGain = FORCE_GAIN_NONE;
	rodParams.pendulumForce = 0;
}

/**
 * @brief
 * Update LCD Display for inverted pendulum game
 *
 * @param[in] baseX
 * The new x coordinate of the cart
 *
 * @param[in] ballX
 * The new x coordinate of the ball
 *
 * @param[in] ballY
 * The new y coordinate of the ball
 */
void updateDisplay(int32_t baseX, int32_t ballX, int32_t ballY)
{
	EMSTATUS lcd_error;
	struct __GLIB_Rectangle_t clippingRect;
	int32_t baseRectPoints[8] = {0, 121, 0, 121, 0, 128, 0, 128};
	int32_t xDiff;

	static bool firstRun = true;
	static int32_t lastBaseX;
	static int32_t lastBallX;
	static int32_t lastBallY;
	clippingRect.yMax = 127;

	// check for bad input values (usually on a game violation case)
	if (ballY > 128 || baseX < 0 || baseX > 128)
		return;

	// Clip items currently on display if last values not null
	if (!firstRun)
	{
		// set xmin, max of clip rect
		xDiff = lastBallX - lastBaseX;
		if (xDiff < 0)
			xDiff *= (-1);
		// ball on left case (or left justified w/base)
		if (lastBallX + 7 <= lastBaseX)
		{
			clippingRect.xMin = lastBallX - 3;
			if (clippingRect.xMin < 0)
				clippingRect.xMin = 0;
			clippingRect.xMax = lastBaseX + 10;
			if (clippingRect.xMax >= 128)
				clippingRect.xMax = 127;
		}
		// ball on right case (or right justified with base)
		else if (lastBallX - 7 >= lastBaseX)
		{
			clippingRect.xMin = lastBaseX - 10;
			if (clippingRect.xMin < 0)
				clippingRect.xMin = 0;
			clippingRect.xMax = lastBallX + 3;
			if (clippingRect.xMax >= 128)
				clippingRect.xMax = 127;
		}
		// ball within bounds of base case
		else if (xDiff < 7)
		{
			clippingRect.xMin = lastBaseX - 10;
			if (clippingRect.xMin < 0)
				clippingRect.xMin = 0;
			clippingRect.xMax = lastBaseX + 10;
			if (clippingRect.xMax > 128)
				clippingRect.xMax = 128;
		}
		// set ymin
		clippingRect.yMin = lastBallY - 3;
		// set clipping region and clip
		// UNIT TEST 11 (if statements after each function call)
		lcd_error = GLIB_setClippingRegion(&glibContext, &clippingRect);
		if (lcd_error != DMD_OK)
			while (true);
		lcd_error = GLIB_clearRegion(&glibContext);
		if (lcd_error != DMD_OK)
			while (true);
		lcd_error = GLIB_resetClippingRegion(&glibContext);
		if (lcd_error != DMD_OK)
			while (true);
	}
	// If last values Null (initial state) clip whole display
	else if (firstRun)
	{
		lcd_error = GLIB_clear(&glibContext);
		if (lcd_error != DMD_OK)
			while (true);
	}

	// update display to clear
	lcd_error = DMD_updateDisplay();
	if (lcd_error != DMD_OK)
		while (true);

	// Update display with input args
	// draw base
	// get base rectangle points based on basex
	baseRectPoints[0] = baseX - 10;
	baseRectPoints[2] = baseX + 10;
	baseRectPoints[4] = baseX + 10;
	baseRectPoints[6] = baseX - 10;
	lcd_error = GLIB_drawPolygonFilled(&glibContext, 4, baseRectPoints);
	if (lcd_error != DMD_OK)
		while (true);
	// draw circle
	lcd_error = GLIB_drawCircleFilled(&glibContext, ballX, ballY, 3);
	if (lcd_error != DMD_OK)
		while (true);
	// draw line between base and circle
	lcd_error = GLIB_drawLine(&glibContext, baseX, 128, ballX, ballY);
	if (lcd_error != DMD_OK)
		while (true);
	// update display with new changes to finish
	lcd_error = DMD_updateDisplay();
	if (lcd_error != DMD_OK)
		while (true);

	// set "last" values to current values (to be used for clipping next time
	lastBaseX = baseX;
	lastBallX = ballX;
	lastBallY = ballY;

	firstRun = false;
}

int main(void) {
	  EMSTATUS status;
	  RTOS_ERR err;

	  BSP_SystemInit();
	  CPU_Init();                                                 /* Initialize CPU.                                      */

	  // Initialize Display
	  /* Initialize the display module. */
	  status = DISPLAY_Init();
	  if (DISPLAY_EMSTATUS_OK != status) {
	    while (1) ;
	  }

	  /* Initialize the DMD module for the DISPLAY device driver. */
	  status = DMD_init(0);
	  if (DMD_OK != status) {
	    while (1) ;
	  }

	  /* Initialize the glib context */
	  status = GLIB_contextInit(&glibContext);
	  if (GLIB_OK != status) {
	    while (1) ;
	  }
	  glibContext.backgroundColor = White;
	  glibContext.foregroundColor = Black;

	  OS_TRACE_INIT();
	  OSInit(&err);                                               /* Initialize the Kernel.                               */
	                                                              /*   Check error code.                                  */
	  APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	  // add startupt task & start OS kernel
	  OSTaskCreate(&MainStartTaskTCB,                          /* Create the Start Task.                               */
	               "Main Start Task",
	                MainStartTask,
	                DEF_NULL,
	                MAIN_START_TASK_PRIO,
	               &MainStartTaskStk[0],
	               (MAIN_START_TASK_STK_SIZE / 10u),
	                MAIN_START_TASK_STK_SIZE,
	                0u,
	                0u,
	                DEF_NULL,
	               (OS_OPT_TASK_STK_CLR),
	               &err);
	                                                              /*   Check error code.                                  */
	  APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	  OSStart(&err);                                              /* Start the kernel.                                    */
	  /*   Check error code.                                  */
	  APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	  return 1;
}

/**
 * @brief
 * Service Physics timer callback function
 *
 * @details
 * Posts to semaphore for periodic servicing of pendulum physics
 */
static	void  SvcPhysicsTimerCallback (OS_TMR p_tmr, void * p_arg)
{
	RTOS_ERR err;
	OSSemPost(&SvcPhysicsTimerSem,
			OS_OPT_POST_ALL,
			&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

/**
 * @brief
 * Measure Capsense timer callback function
 *
 * @details
 * Posts to semaphore for periodic servicing of capsense measurements
 */
static	void  MeasureCapsenseTimerCallback (OS_TMR p_tmr, void * p_arg)
{
	RTOS_ERR err;
	OSSemPost(&MeasureCapsenseTimerSem,
			OS_OPT_POST_ALL,
			&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

//////////// OS FUNCTIONS ////////////
/*
*********************************************************************************************************
*                                          MainStartTask()
*
* Description : This is the task that will be called by the Startup when all services are initializes
*               successfully.
*
* Argument(s) : p_arg   Argument passed from task creation. Unused, in this case.
*
* Return(s)   : None.
*
* Notes       : None.
*********************************************************************************************************
*/
static  void  MainStartTask (void  *p_arg)
{
    RTOS_ERR  err;


    PP_UNUSED_PARAM(p_arg);                                     /* Prevent compiler warning.                            */

    Common_Init(&err);                                          /* Call common module initialization example.           */
    APP_RTOS_ASSERT_CRITICAL(err.Code == RTOS_ERR_NONE, ;);

	EMU_DCDCInit_TypeDef dcdcInit = EMU_DCDCINIT_DEFAULT;
	CMU_HFXOInit_TypeDef hfxoInit = CMU_HFXOINIT_DEFAULT;


	CHIP_Init();


	EMU_EM23Init_TypeDef em23Init = EMU_EM23INIT_DEFAULT;
	EMU_DCDCInit(&dcdcInit);
	em23Init.vScaleEM23Voltage = emuVScaleEM23_LowPower;
	EMU_EM23Init(&em23Init);
	CMU_HFXOInit(&hfxoInit);


	CMU_OscillatorEnable(cmuOsc_HFRCO, true, true);
	CMU_ClockSelectSet(cmuClock_HF, cmuSelect_HFRCO);
	CMU_OscillatorEnable(cmuOsc_HFXO, false, false);


	CMU_ClockEnable(cmuClock_GPIO, true);

    app_peripheral_setup();

    // Initialize rodParams variables to default state
    initRodParams();

	// CREATE ALL OS OBJECTS (3x timers, 4x sems, 1x mutex, 1x flaggrp)
    // FLAGS
	// LED1 Output Flag Group
	OSFlagCreate(&LED1OutFlags,
				"LED1 Output Flags",
				EVENT_FLAGS_INITILZIED_CLEAR,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	// SEMAPHORES
	// Service Physics Timer semaphore
	OSSemCreate(&SvcPhysicsTimerSem,
				"Service Physics Timer Semaphore",
				SEM_INITIALIZED_CLEAR,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LCD Grahpics semaphore
	OSSemCreate(&LCDGraphicsSem,
				"LCD Grahpics Semaphore",
				SEM_INITIALIZED_CLEAR,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Measure Capsense Timer semaphore
	OSSemCreate(&MeasureCapsenseTimerSem,
				"Measure Capsense Timer Semaphore",
				SEM_INITIALIZED_CLEAR,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LED1 Blink Timer Semaphore
	OSSemCreate(&LED1BlinkTimerSem,
				"LED1 Blink Timer Semaphore",
				SEM_INITIALIZED_CLEAR,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	// MUTEXs
	// Pendulum Params Mutex
	OSMutexCreate(&PendulumParamsLock,
				"Pendulum Params Mutex",
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	// TIMERS
	// Service Physics Timer
	OSTmrCreate(&SvcPhysicsTimer,
			   "Service Physics Timer",
			   TIMER_NO_DELAY,
			   TIMER_SVC_PHYSICS_PERIOD,
			   OS_OPT_TMR_PERIODIC,
			   &SvcPhysicsTimerCallback,
			   NULL,
			   &err);
	// check error code
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Measure Capsense Timer
	OSTmrCreate(&MeasureCapsenseTimer,
			   "Measure Capsense Timer",
			   TIMER_NO_DELAY,
			   TIMER_MEASURE_CAPSENSE_PERIOD,
			   OS_OPT_TMR_PERIODIC,
			   &MeasureCapsenseTimerCallback,
			   NULL,
			   &err);
	// check error code
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	// MSG QUEUES
	// Button Input / LED0 Output Queue
	OSQCreate(&ButtonInLED0OutMsgQ,
			  "Button Input / LED0 Output Msg Queue",
			  BTN_IN_LED0_OUT_MAX_MSGQ_QTY,
			  &err);
	// check error code
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    // CREATE ALL OTHER TASKS
	// Idle Task Create
	OSTaskCreate(&IdleTaskTCB,
			   "Idle Task",
				IdleTask,
				DEF_NULL,
				IDLE_TASK_PRIO,
			   &IdleTaskStk[0],
			   (IDLE_TASK_STK_SIZE / 10u),
				IDLE_TASK_STK_SIZE,
				0u,
				0u,
				DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Service Physics Task Create
	OSTaskCreate(&SvcPhysicsTaskTCB,
			   "Service Physics Task",
			   SvcPhysicsTask,
			   DEF_NULL,
				SVC_PHYSICS_TASK_PRIO,
			   &SvcPhysicsTaskStk[0],
			   (SVC_PHYSICS_TASK_STK_SIZE / 10u),
			   SVC_PHYSICS_TASK_STK_SIZE,
			   0u,
			   0u,
			   DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LCD Graphics Task Create
	OSTaskCreate(&LCDGraphicsTaskTCB,
			   "Speed Setpoint Task",
			   LCDGraphicsTask,
			   DEF_NULL,
			   LCD_GRAPHICS_TASK_PRIO,
			   &LCDGraphicsTaskStk[0],
			   (LCD_GRAPHICS_TASK_STK_SIZE / 10u),
			   LCD_GRAPHICS_TASK_STK_SIZE,
			   0u,
			   0u,
			   DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Measure Capsense Task Create
	OSTaskCreate(&MeasureCapsenseTaskTCB,
			   "Measure Capsense Task",
			   MeasureCapsenseTask,
			   DEF_NULL,
			   MEASURE_CAPSENSE_TASK_PRIO,
			   &MeasureCapsenseTaskStk[0],
			   (MEASURE_CAPSENSE_TASK_STK_SIZE / 10u),
			   MEASURE_CAPSENSE_TASK_STK_SIZE,
			   0u,
			   0u,
			   DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Button In / LED0 Out Task Create
	OSTaskCreate(&ButtonInLED0OutTaskTCB,
			   "Button In / LED0 Out Task",
			   ButtonInLED0OutTask,
			   DEF_NULL,
			   BTN_IN_LED0_OUT_TASK_PRIO,
			   &ButtonInLED0OutTaskStk[0],
			   (BTN_IN_LED0_OUT_TASK_STK_SIZE / 10u),
			   BTN_IN_LED0_OUT_TASK_STK_SIZE,
			   0u,
			   0u,
			   DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LED1 Output Task Create
	OSTaskCreate(&LED1OutTaskTCB,
			   "LED1 Output Task",
			   LED1OutTask,
			   DEF_NULL,
			   LED1_OUT_TASK_PRIO,
			   &LED1OutTaskStk[0],
			   (LED1_OUT_TASK_STK_SIZE / 10u),
			   LED1_OUT_TASK_STK_SIZE,
			   0u,
			   0u,
			   DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    // delete self task & check error code
    OSTaskDel(NULL, &err);
    APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

/**
 * @brief OS Idle Task - custom implementation
 *
 * @details Goes into EM1
 */
static void IdleTask(void *p_arg)
{
    PP_UNUSED_PARAM(p_arg);                                     /* Prevent compiler warning.                            */

    while (INFINITE_LOOP)
    {
    	EMU_EnterEM1();
    }
}

/**
 * @brief
 * Service Physics Task
 *
 * @details
 * Task runs every Tphy (TIMER_SVC_PHYSICS_PERIOD).  Services physics for
 * Inverted Pendulum game
 *
 */
static void	SvcPhysicsTask(void * p_arg)
{
    RTOS_ERR  	err;
    CPU_BOOLEAN tmrStartSuccess;
    // values to be READ from rodParams
    double		currPendulumBallVelocX;
    double 	currPendulumBallVelocY;
    int32_t 	currPendulumBallX;
    int32_t 	currPendulumBallY;
    int32_t 	currPendulumBaseX;
    double 		currPendulumTheta;
    uint16_t 	currPendulumForceGain;
    int32_t	 	currPendulumForce;
    // values to be WRITTEN to rodParams
    double 	nextPendulumBallVelocX;
    double		nextPendulumBallVelocY;
    int32_t		nextPendulumBallX;
    int32_t 	nextPendulumBallY;
    int32_t 	nextPendulumBaseX;
    double		nextPendulumTheta;
    // local values for calculations
    double 		currPendulumAccelX;
    double		currPendulumAccelY;
    static bool	thetaNeg;
    double		thetaArg;
    bool 		violationFlagged = false;

    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    // Start Periodic Physics Servicing Timer
    tmrStartSuccess = OSTmrStart(&SvcPhysicsTimer,
    		   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// UNIT TEST 9A: confirming timer started
	if (tmrStartSuccess == DEF_FALSE)
		while(INFINITE_LOOP);

    while (INFINITE_LOOP)
    {
    	// delay
    	OSTimeDly(TIMER_SVC_PHYSICS_PERIOD,
    			  OS_OPT_TIME_PERIODIC,
				  &err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Acquire rodParams lock
    	OSMutexPend(&PendulumParamsLock,
    			    MUTEX_PEND_FOREVER,
					OS_OPT_PEND_BLOCKING,
					NULL,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Read vars from rodParams, quickly
    	currPendulumBallVelocX = rodParams.pendulumBallVelocX;
    	currPendulumBallVelocY = rodParams.pendulumBallVelocY;
    	currPendulumBallX = rodParams.pendulumBallX;
    	currPendulumBallY = rodParams.pendulumBallY;
    	currPendulumBaseX = rodParams.pendulumBaseX;
    	currPendulumTheta = rodParams.pendulumTheta;
    	currPendulumForceGain = rodParams.pendulumForceGain;
    	currPendulumForce = rodParams.pendulumForce * currPendulumForceGain;

    	// Release rodParams lock
    	OSMutexPost(&PendulumParamsLock,
    			    OS_OPT_POST_NONE,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// calculate new values for rodParams
    	// based on force, calculate TOTAL ACCELERATION
    	currPendulumAccelX = (1 - cos(2 * currPendulumTheta));
    	if (currPendulumForce != 0)
    		currPendulumAccelX *= currPendulumForce;
    	currPendulumAccelX /= 1000;

    	currPendulumAccelY = (sin(2 * currPendulumTheta));
    	if (currPendulumForce != 0)
    		currPendulumAccelY *= currPendulumForce;
    	if (fabs(currPendulumTheta) > 0.15633)
			currPendulumAccelY += MASS_BALL * ACCEL_GRAVITY;
    	currPendulumAccelY *= -1;
    	currPendulumAccelY /= 100;

    	// Clamp acceleration
    	if (currPendulumAccelX > 0 && currPendulumAccelX > 100.0)
    		currPendulumAccelX = 100.0;
    	else if (currPendulumAccelX < 0 && currPendulumAccelX < -100.0)
    		currPendulumAccelX = -100.0;
    	if (currPendulumAccelY > 0 && currPendulumAccelY > 100.0)
    		currPendulumAccelY = 100.0;
    	else if (currPendulumAccelY < 0 && currPendulumAccelY < -100.0)
    		currPendulumAccelY = -100.0;

    	// based on accelration, previous velocity, calculate new velocity
    	nextPendulumBallVelocX = currPendulumBallVelocX + currPendulumAccelX;
    	nextPendulumBallVelocY = currPendulumBallVelocY + currPendulumAccelY;

    	// Check for theta shifts
    	if (currPendulumBallVelocY > 0 && nextPendulumBallVelocY < 0 && fabs(currPendulumTheta) < 0.0523)
    	{
    		if (currPendulumBallX < currPendulumBaseX)
    			thetaNeg = false;
    		else
    			thetaNeg = true;
    	}

    	// clamp velocity
    	if (nextPendulumBallVelocX > 0 && nextPendulumBallVelocX > 100.0)
    		nextPendulumBallVelocX = 100.0;
    	else if (nextPendulumBallVelocX < 0 && nextPendulumBallVelocX < -100.0)
    		nextPendulumBallVelocX = -100.0;
    	if (nextPendulumBallVelocY > 0 && nextPendulumBallVelocY > 100.0)
    		nextPendulumBallVelocY = 100.0;
    	else if (nextPendulumBallVelocY < 0 && nextPendulumBallVelocY < -100.0)
    		nextPendulumBallVelocY = -100.0;

    	// based on old position of ball and new velocity, calculate new position of ball
    	nextPendulumBallX = currPendulumBallX + nextPendulumBallVelocX;
    	nextPendulumBallY = currPendulumBallY + nextPendulumBallVelocY;

    	// clamp y
    	if (nextPendulumBallY < BALL_Y_DEFAULT)
    	{
    		nextPendulumBallY = BALL_Y_DEFAULT;
    		nextPendulumBallVelocY = 0;
    	}

    	// compute new theta
    	// starttheta == zero case, initial
    	if (currPendulumTheta == THETA_DEFAULT)
    	{
    		// initial force to the right
    		if (currPendulumForce > 0)
    		{
    			thetaNeg = true;
    			nextPendulumTheta = THETA_START_LEFT;
    			nextPendulumBallY = BALL_Y_DEFAULT + 1;
    		}
    		// initial force to the left
    		else if (currPendulumForce < 0)
    		{
    			thetaNeg = false;
    			nextPendulumTheta = THETA_START_RIGHT;
    			nextPendulumBallY = BALL_Y_DEFAULT + 1;
    		}
    		// initial force zero
    		else if (currPendulumForce == 0)
    			nextPendulumTheta = 0;
    	}
    	// starttheta not zero case
    	else
    	{
    		thetaArg = (double)(128 - nextPendulumBallY) / LENGTH_POST;
    		nextPendulumTheta = acos(thetaArg);

    		// shift theta sign if moving thru theta = 0
    		if (thetaNeg)
    			nextPendulumTheta *= -1;
    	}

    	// compute new Base X
    	if (nextPendulumTheta == 0)
    		nextPendulumBaseX = nextPendulumBallX;
    	else if (nextPendulumTheta < 0)
    		nextPendulumBaseX = nextPendulumBallX - (int32_t)(LENGTH_POST * sin(nextPendulumTheta));
    	else if (nextPendulumTheta > 0)
    		nextPendulumBaseX = nextPendulumBallX - (int32_t)(LENGTH_POST * sin(nextPendulumTheta));

    	// Check for "pendulumFell" violation
    	// if found, set flag to be processed by LED1OutTask
    	// UNIT TEST 1: Testing Theta Boundary Conditions
    	if (nextPendulumBallY > VIOLATION_PENDULUM_FELL)
    	{
    		OSFlagPost(&LED1OutFlags,
    				   FLAG_PENDLM_FELL_VIOLATION,
					   OS_OPT_POST_FLAG_SET,
					   &err);
        	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
        	violationFlagged = true;
        	OSTaskDel(&SvcPhysicsTaskTCB, &err);
        	OSTaskDel(&MeasureCapsenseTaskTCB, &err);
    	}
    	// Check for "xmax" violation
    	// if found, set flag to be processed by LED1OutTask
    	// UNIT TEST 2: Testing Xmax & XMin Boundary Conditions
    	if ((nextPendulumBaseX >= VIOLATION_XMAX) || (nextPendulumBaseX <= VIOLATION_XMIN))
    	{
    		OSFlagPost(&LED1OutFlags,
    				   FLAG_XMAX_VIOLATION,
					   OS_OPT_POST_FLAG_SET,
					   &err);
        	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
        	violationFlagged = true;
        	OSTaskDel(&SvcPhysicsTaskTCB, &err);
        	OSTaskDel(&MeasureCapsenseTaskTCB, &err);
    	}

    	// Acquire rodParams lock
    	OSMutexPend(&PendulumParamsLock,
    			    MUTEX_PEND_FOREVER,
					OS_OPT_PEND_BLOCKING,
					NULL,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Enter new values in to rodParams
    	rodParams.pendulumBallVelocX = nextPendulumBallVelocX;
    	rodParams.pendulumBallVelocY = nextPendulumBallVelocY;
    	rodParams.pendulumBallX = nextPendulumBallX;
    	rodParams.pendulumBallY = nextPendulumBallY;
    	rodParams.pendulumBaseX = nextPendulumBaseX;
    	rodParams.pendulumTheta = nextPendulumTheta;

    	// Release rodParams lock
    	OSMutexPost(&PendulumParamsLock,
    			    OS_OPT_POST_NONE,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Post to LCD Grahpics Sem
    	if (!violationFlagged)
    	{
			OSSemPost(&LCDGraphicsSem, OS_OPT_POST_ALL, &err);
			APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
    	}
    }
}

/**
 * @brief
 * LCD Graphics Task
 *
 * @details
 * Periodic task that runs every Tlcd (TIMER_LCD_GRAPHICS_PERIOD).
 * Updates LCD Graphics Display based on latest location of rod
 * in rodParams.
 *
 */
static void	LCDGraphicsTask(void * p_arg)
{
    RTOS_ERR  err;
    CPU_BOOLEAN tmrStartSuccess;

    int32_t currPendulumBallX;
    int32_t currPendulumBallY;
    int32_t currPendulumBaseX;

    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

	// Draw default start display
	updateDisplay(BASE_X_DEFAULT, BALL_X_DEFAULT, BALL_Y_DEFAULT);

    while (INFINITE_LOOP)
    {
    	// Pend on timer sem
    	OSSemPend(&LCDGraphicsSem,
    			  SEM_PEND_FOREVER,
				  OS_OPT_PEND_BLOCKING,
				  NULL,
				  &err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Acquire rodParams lock
    	OSMutexPend(&PendulumParamsLock,
    			    MUTEX_PEND_FOREVER,
					OS_OPT_PEND_BLOCKING,
					NULL,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Quickly get vars from rodParams
    	currPendulumBallX = rodParams.pendulumBallX;
    	currPendulumBallY = rodParams.pendulumBallY;
    	currPendulumBaseX = rodParams.pendulumBaseX;

    	// Release rodParams lock
    	OSMutexPost(&PendulumParamsLock,
    			    OS_OPT_POST_NONE,
					&err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// update display
    	updateDisplay(currPendulumBaseX, currPendulumBallX, currPendulumBallY);
    }
}

/**
 * @brief
 * Measure Capsense Task
 *
 * @details
 * Periodic every Tcap (TIMER_MEASURE_CAPSENSE_PERIOD)
 * Measures user input on capsense slider, and updates
 * "pendulumForce" variable in rodParams
 *
 */
static void	MeasureCapsenseTask(void * p_arg)
{
    RTOS_ERR  err;
    CPU_BOOLEAN tmrStartSuccess;
    int32_t sliderPositionRaw;
    int16_t currPendulumForce;
    static int16_t lastPendulumForce = SLIDER_NO_FORCE;
    struct CapsenseData capsenseResults;
	bool test_hard_left_pressed;
	bool test_soft_left_pressed;
	bool test_hard_right_pressed;
	bool test_soft_right_pressed;

    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    // initialize CAPSENSE module
    CAPSENSE_Init();

    // Start Periodic Timer to Measure Capsense Input
    tmrStartSuccess = OSTmrStart(&MeasureCapsenseTimer,
    		   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// UNIT TEST 9C: confirming timer started
	if (tmrStartSuccess == DEF_FALSE)
		while(INFINITE_LOOP);

    while (INFINITE_LOOP)
    {
    	// Pend on timer sem
    	OSSemPend(&MeasureCapsenseTimerSem,
    			  SEM_PEND_FOREVER,
				  OS_OPT_PEND_BLOCKING,
				  NULL,
				  &err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// measure capsense
    	capsenseResults =  sample_cap_project();

    	// interpret capsense results
        // UNIT TEST 4: making sure Force Values are as expected
    	// hard left only pressed
    	if (capsenseResults.hard_left_pressed && !capsenseResults.soft_left_pressed &&
			!capsenseResults.soft_right_pressed && !capsenseResults.hard_right_pressed)
    		currPendulumForce = SLIDER_HARD_LEFT_FORCE;
    	// soft left only, or hard & soft left = soft left
    	else if (capsenseResults.soft_left_pressed &&
    		!capsenseResults.soft_right_pressed && !capsenseResults.hard_right_pressed)
    		currPendulumForce = SLIDER_SOFT_LEFT_FORCE;
    	// soft right only, or hard & soft right = soft right
    	else if (capsenseResults.soft_right_pressed &&
    		!capsenseResults.soft_left_pressed && !capsenseResults.hard_left_pressed)
    		currPendulumForce = SLIDER_HARD_RIGHT_FORCE;
    	// hard right only pressed
    	else if (capsenseResults.hard_right_pressed && !capsenseResults.soft_left_pressed &&
			!capsenseResults.soft_right_pressed && !capsenseResults.hard_left_pressed)
    		currPendulumForce = SLIDER_SOFT_RIGHT_FORCE;
    	// everything else is either nothing pressed or a fluke: no force
    	else
    		currPendulumForce = SLIDER_NO_FORCE;

        // If force has changed, update values in rodParams
        // FUNCTIONAL TEST 5 - set breakpoint on next line of code below if testing //
        // UNIT TEST 10: Making sure force value changed before updating shared data
        if (currPendulumForce != lastPendulumForce)
        {
        	// Acquire rodParams lock
        	OSMutexPend(&PendulumParamsLock,
        			    MUTEX_PEND_FOREVER,
    					OS_OPT_PEND_BLOCKING,
    					NULL,
    					&err);
        	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

			// Quickly update pendulumForce in rodParams
        	rodParams.pendulumForce = currPendulumForce;
        	// UNIT TEST 6: Confirming shared force data was actually updated
        	if (rodParams.pendulumForce != currPendulumForce)
        		while (INFINITE_LOOP);

			// Release lock on rodParams
        	OSMutexPost(&PendulumParamsLock,
        			    OS_OPT_POST_NONE,
    					&err);
        	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
        }
        // Update last force value
        lastPendulumForce = currPendulumForce;
    }
}

/**
 * @brief
 * Button Input / LED0 Output Task
 *
 * @details
 * Triggered by GPIO ISR, adjusts force gain coefficient "pendulumForceGain"
 * in rodParams, and also adjusts led0 PWM based on pendulumForceGain, to
 * provide a visual reference.
 *
 */
static void	ButtonInLED0OutTask(void * p_arg)
{
    RTOS_ERR  err;
    uint16_t currPendulumForceGain;
    OS_MSG_SIZE size;
    static uint16_t lastPendulumForceGain = FORCE_GAIN_NONE;
    ButtonMessage * rcvd_msg;
    void * rcvd_msg_raw;
    static uint16_t currLED0PWMOnTime = (PWM_PERIOD * FORCE_GAIN_NONE) / 10;

    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    // INIT LED0 off
    GPIO_PinOutClear(LED0_port, LED0_pin);

    while (INFINITE_LOOP)
    {
    	rcvd_msg_raw = NULL;
    	rcvd_msg = NULL;
    	// nb pend on buttoninled0outmsgq
    	rcvd_msg_raw = OSQPend(&ButtonInLED0OutMsgQ,
    									       MSGQ_PEND_FOREVER,
											   OS_OPT_PEND_NON_BLOCKING,
											   &size,
											   NULL,
											   &err);

    	// if message was rcvd:
    	if (rcvd_msg_raw != NULL)
    	{
    		rcvd_msg = (ButtonMessage *) rcvd_msg_raw;
			// acquire rodparams lock
        	OSMutexPend(&PendulumParamsLock,
        			    MUTEX_PEND_FOREVER,
    					OS_OPT_PEND_BLOCKING,
    					NULL,
    					&err);
        	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
			// UNIT TEST 5: confirm buttons are actually adjusting force gain value
        	if (rodParams.pendulumForceGain != lastPendulumForceGain)
        		while (INFINITE_LOOP);
			// Quickly update pendulumForceGain
        	// UNIT TEST 3: testing force gain boundary conditions (high and low)
        	if 		(rcvd_msg->button == btn0 && (rodParams.pendulumForceGain + FORCE_GAIN_ADJUST_VALUE) <= FORCE_GAIN_MAX_VALUE)
        		rodParams.pendulumForceGain += FORCE_GAIN_ADJUST_VALUE;
        	else if (rcvd_msg->button == btn1 && (rodParams.pendulumForceGain - FORCE_GAIN_ADJUST_VALUE) >= FORCE_GAIN_NONE)
        		rodParams.pendulumForceGain -= FORCE_GAIN_ADJUST_VALUE;
        	// get new value (to be used for LED0 PWM)
        	currPendulumForceGain = rodParams.pendulumForceGain;
    		// Release lock on rodParams
        	OSMutexPost(&PendulumParamsLock,
        			    OS_OPT_POST_NONE,
    					&err);
        	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
			// get new pwm value
        	currLED0PWMOnTime = (PWM_PERIOD * currPendulumForceGain) / 10;
			// set last to curr
        	lastPendulumForceGain = currPendulumForceGain;
        	// UNIT TEST 8: confirming buttons actualkly adjust LED0 PWM value
        	if (currLED0PWMOnTime != (PWM_PERIOD * currPendulumForceGain) / 10)
        		while (true);
    	}

    	// led on, delay, off, delay
    	GPIO_PinOutSet(LED0_port, LED0_pin);
    	OSTimeDly(currLED0PWMOnTime,
    			  OS_OPT_TIME_PERIODIC,
				  &err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
    	GPIO_PinOutClear(LED0_port, LED0_pin);
    	OSTimeDly((PWM_PERIOD - currLED0PWMOnTime),
    			  OS_OPT_TIME_PERIODIC,
				  &err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
    }
}

/**
 * @brief
 * LED1 Output Task
 *
 * @details
 * In the case of a game violation (either pendulum fell, or base left
 * x-limits of screen), adjusts LED1 and ends game until reset.
 * For pendlm_fell: de-illuminates LED1 and ends game
 * For xmax_violation: blink LED1 at 1Hz and ends game
 *
 * @note
 * Also illuminates LED1 solid at startup
 *
 */
static void	LED1OutTask(void * p_arg)
{
    RTOS_ERR  err;
    OS_FLAGS flaggedViolation;
    CPU_BOOLEAN tmrStartSuccess;

    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    // Illuminate LED1, solid
	GPIO_PinOutClear(LED1_port, LED1_pin);


    while (INFINITE_LOOP)
    {
    	// Pend on led1outflags
    	flaggedViolation = OSFlagPend(&LED1OutFlags,
    			                  FLAG_BOTH_VIOLATIONS,
								  FLAG_PEND_FOREVER,
								  OS_OPT_PEND_FLAG_SET_ANY,
								  NULL,
								  &err);
    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    	// Parse Violation Type
    	// XMax/XMin Violation
    	if (flaggedViolation == FLAG_XMAX_VIOLATION)
    	{
    		// Start LED1 Blink Timer
    	    tmrStartSuccess = OSTmrStart(&LED1BlinkTimer,
    	    		   &err);
    		APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
    		// UNIT TEST 9D: confirming timer started
    		if (tmrStartSuccess == DEF_FALSE)
    			while(INFINITE_LOOP);
    		// Go into infinite loop, toggling LED1 at 1Hz
    		while (INFINITE_LOOP)
    		{
    			// Pend on LED1 Blink Timer Sem
    	    	OSSemPend(&LED1BlinkTimerSem,
    	    			  SEM_PEND_FOREVER,
    					  OS_OPT_PEND_BLOCKING,
    					  NULL,
    					  &err);
    	    	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    			// Toggle LED1
    	    	GPIO_PinOutToggle(LED1_port, LED1_pin);
    		}
    	}
    	// Pendulum Fell Violation
    	if (flaggedViolation == FLAG_PENDLM_FELL_VIOLATION)
    	{
    		// de-illuminate LED1
    		GPIO_PinOutSet(LED1_port, LED1_pin);
    		// enter infinite loop
    		while (INFINITE_LOOP);
    	}
    }
}


